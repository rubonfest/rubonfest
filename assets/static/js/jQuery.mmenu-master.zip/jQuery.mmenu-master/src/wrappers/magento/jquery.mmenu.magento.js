/*	
 * Magento wrapper for jQuery mmenu
 * Include this file after including the jquery.mmenu plugin for default Magento support.
 */


(function( $ ) {

	var _PLUGIN_ = 'mmenu';

	$[ _PLUGIN_ ].configuration.classNames.selected = 'active';

})( jQuery );